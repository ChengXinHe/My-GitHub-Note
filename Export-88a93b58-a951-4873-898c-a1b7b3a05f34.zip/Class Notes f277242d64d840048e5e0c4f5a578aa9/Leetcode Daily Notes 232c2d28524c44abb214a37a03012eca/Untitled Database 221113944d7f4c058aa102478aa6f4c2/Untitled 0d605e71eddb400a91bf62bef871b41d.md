# Untitled

summary: 通过使用辅助函数，增加函数参数列表，在参数中携带额外信息