# The Leetcode Python Cheat Sheet

Class: MAT 630
Created: June 7, 2022 10:35 PM
Materials: discrete.pdf
Reviewed: No
Type: Leetcode

- **Tree**
    1. 
- ****求字符差值****
    
    ```python
    print(ord'a'-ord'b')
    ```
    
-